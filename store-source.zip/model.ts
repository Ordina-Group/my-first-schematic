export interface Model {
  id: string | number;
  name: string;
}
